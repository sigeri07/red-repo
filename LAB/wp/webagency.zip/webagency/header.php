<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="fixed w-full z-50 bg-white shadow-md">
    <nav class="container mx-auto px-6 py-4">
        <div class="flex items-center justify-between">
            <div class="text-2xl font-bold text-blue-600">
                <a href="<?php echo home_url(); ?>">WebAgency</a>
            </div>
            <div class="hidden md:flex space-x-8">
                <a href="#home" class="text-gray-700 hover:text-blue-600 transition">Home</a>
                <a href="#cases" class="text-gray-700 hover:text-blue-600 transition">Cases</a>
                <a href="#team" class="text-gray-700 hover:text-blue-600 transition">Team</a>
                <a href="#contact" class="text-gray-700 hover:text-blue-600 transition">Contact</a>
            </div>
            <div class="md:hidden">
                <button id="mobile-menu-btn" class="text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>
        </div>
        <div id="mobile-menu" class="hidden md:hidden mt-4">
            <a href="#home" class="block py-2 text-gray-700 hover:text-blue-600">Home</a>
            <a href="#cases" class="block py-2 text-gray-700 hover:text-blue-600">Cases</a>
            <a href="#team" class="block py-2 text-gray-700 hover:text-blue-600">Team</a>
            <a href="#contact" class="block py-2 text-gray-700 hover:text-blue-600">Contact</a>
        </div>
    </nav>
</header>
