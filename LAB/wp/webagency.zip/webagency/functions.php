<?php
/**
 * WebAgency Theme Functions
 */

// Theme Setup
function webagency_setup()
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'webagency_setup');


// Note: COOP/COEP headers removed - no longer needed since we switched from
// whisper.cpp (pthreads) to Transformers.js which doesn't require SharedArrayBuffer

function webagency_scripts()
{
    // Tailwind CSS from CDN
    wp_enqueue_style('tailwind', 'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css');

    // Custom styles
    wp_enqueue_style('webagency-style', get_stylesheet_uri());
    wp_enqueue_style('webagency-custom', get_template_directory_uri() . '/assets/css/custom.css');

    // Swiper for slider
    wp_enqueue_style('swiper', 'https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css');
    wp_enqueue_script('swiper', 'https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js', array(), '8.0', true);

    // Transformers.js whisper wrapper (loads Transformers.js dynamically as ES module)
    //wp_enqueue_script('whisper-wrapper', get_template_directory_uri() . '/assets/js/whisper/whisper-wrapper.js', array(), '1.0', true);

    // Localize script data for whisper-wrapper (needs theme_url and site_url)
    wp_localize_script('whisper-wrapper', 'webagency_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('webagency_nonce'),
        'theme_url' => get_template_directory_uri(),
        'site_url' => get_site_url()
    ));

    // Custom scripts (depends on whisper being loaded)
    wp_enqueue_script('webagency-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery', 'whisper-wrapper'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'webagency_scripts');

// Register Custom Post Types
function webagency_custom_post_types()
{
    // Cases Post Type
    register_post_type('case', array(
        'labels' => array(
            'name' => 'Cases',
            'singular_name' => 'Case',
            'add_new' => 'Add New Case',
            'add_new_item' => 'Add New Case',
            'edit_item' => 'Edit Case',
            'new_item' => 'New Case',
            'view_item' => 'View Case',
            'search_items' => 'Search Cases',
            'not_found' => 'No cases found',
            'not_found_in_trash' => 'No cases found in trash'
        ),
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true
    ));

    // Team Members Post Type
    register_post_type('team_member', array(
        'labels' => array(
            'name' => 'Team Members',
            'singular_name' => 'Team Member',
            'add_new' => 'Add New Member',
            'add_new_item' => 'Add New Team Member',
            'edit_item' => 'Edit Team Member',
            'new_item' => 'New Team Member',
            'view_item' => 'View Team Member',
            'search_items' => 'Search Team Members',
            'not_found' => 'No team members found',
            'not_found_in_trash' => 'No team members found in trash'
        ),
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-groups',
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true
    ));

    // Contact Submissions Post Type
    register_post_type('contact_submission', array(
        'labels' => array(
            'name' => 'Contact Submissions',
            'singular_name' => 'Contact Submission',
            'all_items' => 'All Submissions',
            'edit_item' => 'View Submission',
            'view_item' => 'View Submission',
            'search_items' => 'Search Submissions',
            'not_found' => 'No submissions found',
            'not_found_in_trash' => 'No submissions found in trash'
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-email',
        'supports' => array('title', 'editor'),
        'capabilities' => array(
            'create_posts' => false,
        ),
        'map_meta_cap' => true,
        'show_in_rest' => true
    ));
}
add_action('init', 'webagency_custom_post_types');

// Add custom meta boxes for team members
function webagency_add_meta_boxes()
{
    add_meta_box('team_member_position', 'Position', 'webagency_team_position_callback', 'team_member', 'side');
    add_meta_box('contact_submission_details', 'Submission Details', 'webagency_contact_details_callback', 'contact_submission', 'normal');
}
add_action('add_meta_boxes', 'webagency_add_meta_boxes');

function webagency_team_position_callback($post)
{
    $position = get_post_meta($post->ID, '_team_position', true);
    echo '<input type="text" name="team_position" value="' . esc_attr($position) . '" class="widefat">';
}

function webagency_contact_details_callback($post)
{
    $email = get_post_meta($post->ID, '_contact_email', true);
    $phone = get_post_meta($post->ID, '_contact_phone', true);
    $message = get_post_meta($post->ID, '_contact_message', true);
    $has_recording = get_post_meta($post->ID, '_has_voice_recording', true);

    echo '<p><strong>Email:</strong> ' . esc_html($email) . '</p>';
    echo '<p><strong>Phone:</strong> ' . esc_html($phone) . '</p>';
    echo '<p><strong>Message:</strong><br>' . nl2br($message) . '</p>';

    if ($has_recording) {
        $recording_url = wp_get_attachment_url(get_post_meta($post->ID, '_voice_recording_id', true));
        if ($recording_url) {
            echo '<p><strong>Voice Recording:</strong><br>';
            echo '<audio controls><source src="' . esc_url($recording_url) . '" type="audio/webm"></audio>';
            echo '</p>';
        }

        $transcription = get_post_meta($post->ID, '_voice_transcription', true);
        $transcription_status = get_post_meta($post->ID, '_transcription_status', true);
        $summary = get_post_meta($post->ID, '_voice_summary', true);
        $summary_status = get_post_meta($post->ID, '_summary_status', true);

        // Display AI Summary Section
        echo '<div style="margin-top: 15px;">';
        echo '<p><strong>AI Summary:</strong></p>';

        if ($summary_status === 'completed' && $summary) {
            echo '<div style="background: #e7f5ff; padding: 15px; border-left: 4px solid #0073aa; margin-bottom: 15px; border-radius: 4px;">';
            echo '<p style="margin: 0; line-height: 1.6;">' . nl2br($summary) . '</p>';

            $model_used = get_post_meta($post->ID, '_summary_model', true);
            if ($model_used) {
                echo '<p style="margin: 10px 0 0 0; font-size: 11px; color: #666;"><em>Generated by: ' . esc_html($model_used) . '</em></p>';
            }
            echo '</div>';
        } elseif ($summary_status === 'failed') {
            echo '<div style="background: #fff3cd; padding: 10px; border-left: 4px solid #f0b849; margin-bottom: 15px; border-radius: 4px;">';
            echo '<em style="color: #856404;">Summary generation failed</em>';
            echo '</div>';
        } elseif ($summary_status === 'pending') {
            echo '<div style="background: #fff3cd; padding: 10px; border-left: 4px solid #f0b849; margin-bottom: 15px; border-radius: 4px;">';
            echo '<em style="color: #856404;">Summary generation in progress...</em>';
            echo '</div>';
        } elseif ($transcription_status === 'completed') {
            echo '<div style="background: #fff3cd; padding: 10px; border-left: 4px solid #f0b849; margin-bottom: 15px; border-radius: 4px;">';
            echo '<em style="color: #856404;">Summary not yet generated. Use bulk action to generate.</em>';
            echo '</div>';
        } else {
            echo '<em style="color: #999;">No summary available</em>';
        }
        echo '</div>';

        // Display Full Transcription Section (collapsible)
        echo '<div style="margin-top: 15px;">';
        echo '<details>';
        echo '<summary style="cursor: pointer; font-weight: bold; padding: 5px 0;">Full Transcription</summary>';

        if ($transcription_status === 'completed' && $transcription) {
            echo '<div style="background: #f9f9f9; padding: 15px; border-left: 3px solid #999; margin-top: 10px; border-radius: 4px;">';
            echo '<p style="margin: 0; line-height: 1.6;">' . nl2br($transcription) . '</p>';
            echo '</div>';
        } elseif ($transcription_status === 'failed') {
            echo '<div style="margin-top: 10px;"><em style="color: #999;">Transcription failed</em></div>';
        } elseif ($transcription_status === 'pending') {
            echo '<div style="margin-top: 10px;"><em style="color: #999;">Transcription pending...</em></div>';
        } else {
            echo '<div style="margin-top: 10px;"><em style="color: #999;">No transcription available</em></div>';
        }

        echo '</details>';
        echo '</div>';
    }
}

// Save meta boxes
function webagency_save_meta_boxes($post_id)
{
    if (isset($_POST['team_position'])) {
        update_post_meta($post_id, '_team_position', sanitize_text_field($_POST['team_position']));
    }
}
add_action('save_post', 'webagency_save_meta_boxes');

// AJAX Handler for Contact Form
function webagency_handle_contact_form()
{
    check_ajax_referer('webagency_nonce', 'nonce');

    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $message = $_POST['message'];

    // Create contact submission post
    $post_id = wp_insert_post(array(
        'post_title' => 'Contact from ' . $name,
        'post_type' => 'contact_submission',
        'post_status' => 'publish',
        'post_content' => $message
    ));

    if ($post_id) {
        update_post_meta($post_id, '_contact_email', $email);
        update_post_meta($post_id, '_contact_phone', $phone);
        update_post_meta($post_id, '_contact_message', $message);

        // Note: Text messages don't have AI processing (only voice calls are processed client-side)

        wp_send_json_success(array(
            'message' => 'Thank you for contacting us! We will get back to you soon.',
            'post_id' => $post_id
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to submit form. Please try again.'));
    }
}
add_action('wp_ajax_submit_contact_form', 'webagency_handle_contact_form');
add_action('wp_ajax_nopriv_submit_contact_form', 'webagency_handle_contact_form');

/**
 * Symmetric encryption key for client-server communication
 */
define('WEBAGENCY_ENCRYPTION_KEY', 'bLs6z8iv3gWpsvyeabFosDjb4YQe7jdU13rI');

/**
 * Handle raw voice recording upload (Phase 1)
 * Called immediately after recording ends to save audio file
 */
function webagency_save_voice_raw()
{
    check_ajax_referer('webagency_nonce', 'nonce');

    // Create contact submission post
    $post_id = wp_insert_post(array(
        'post_title' => 'Voice Call - ' . date('Y-m-d H:i:s'),
        'post_type' => 'contact_submission',
        'post_status' => 'publish',
        'post_content' => 'Voice call - processing in progress'
    ));

    if (!$post_id) {
        wp_send_json_error(array('message' => 'Failed to create submission.'));
    }

    // Mark as processing
    update_post_meta($post_id, '_has_voice_recording', true);
    update_post_meta($post_id, '_transcription_status', 'pending');
    update_post_meta($post_id, '_summary_status', 'pending');
    update_post_meta($post_id, '_transcription_method', 'client-side');

    // Save audio file if provided
    if (isset($_FILES['voice_recording'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $attachment_id = media_handle_upload('voice_recording', $post_id);

        if (!is_wp_error($attachment_id)) {
            update_post_meta($post_id, '_voice_recording_id', $attachment_id);
            error_log('[WebAgency] Audio file saved for post ' . $post_id . ': attachment ' . $attachment_id);
        } else {
            error_log('[WebAgency] Failed to save audio file for post ' . $post_id . ': ' . $attachment_id->get_error_message());
        }
    }

    wp_send_json_success(array(
        'message' => 'Audio saved, processing started.',
        'post_id' => $post_id
    ));
}

add_action('wp_ajax_save_voice_raw', 'webagency_save_voice_raw');
add_action('wp_ajax_nopriv_save_voice_raw', 'webagency_save_voice_raw');

/**
 * Decrypt AES-GCM encrypted payload from client
 * 
 * @param string $encryptedData Base64 encoded encrypted data with IV prepended
 * @return string|false Decrypted string or false on failure
 */
function webagency_decrypt_payload($encryptedData)
{
    $key = hash('sha256', WEBAGENCY_ENCRYPTION_KEY, true);

    $decoded = base64_decode($encryptedData);
    if ($decoded === false) {
        error_log('[WebAgency] Failed to decode base64');
        return false;
    }

    // IV is first 12 bytes, auth tag is last 16 bytes, ciphertext is in between
    if (strlen($decoded) < 28) { // 12 (IV) + 16 (tag) minimum
        error_log('[WebAgency] Encrypted data too short');
        return false;
    }

    $iv = substr($decoded, 0, 12);
    $tag = substr($decoded, -16);
    $ciphertext = substr($decoded, 12, -16);

    $decrypted = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );

    if ($decrypted === false) {
        error_log('[WebAgency] Decryption failed: ' . openssl_error_string());
        return false;
    }

    return $decrypted;
}

/**
 * Handle encrypted voice results (Phase 2)
 * Called after client-side transcription and summarization complete
 */
function webagency_save_voice_results()
{
    check_ajax_referer('webagency_nonce', 'nonce');

    if (!isset($_POST['post_id']) || !isset($_POST['encrypted_payload'])) {
        wp_send_json_error(array('message' => 'Missing required fields.'));
    }

    $post_id = intval($_POST['post_id']);
    $encrypted_payload = $_POST['encrypted_payload'];

    // Verify post exists and is a contact submission
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'contact_submission') {
        wp_send_json_error(array('message' => 'Invalid submission.'));
    }

    // Decrypt payload
    $decrypted = webagency_decrypt_payload($encrypted_payload);
    if ($decrypted === false) {
        update_post_meta($post_id, '_transcription_status', 'failed');
        update_post_meta($post_id, '_summary_status', 'failed');
        wp_send_json_error(array('message' => 'Decryption failed.'));
    }

    // Parse JSON payload
    $data = json_decode($decrypted, true);
    if (!$data || !isset($data['transcription']) || !isset($data['summary'])) {
        update_post_meta($post_id, '_transcription_status', 'failed');
        update_post_meta($post_id, '_summary_status', 'failed');
        wp_send_json_error(array('message' => 'Invalid payload format.'));
    }

    // Save transcription and summary
    $transcription = $data['transcription'];
    $summary = $data['summary'];

    update_post_meta($post_id, '_voice_transcription', $transcription);
    update_post_meta($post_id, '_transcription_status', 'completed');
    update_post_meta($post_id, '_voice_summary', $summary);
    update_post_meta($post_id, '_summary_status', 'completed');
    update_post_meta($post_id, '_summary_model', 'client-side-distilbart');

    // Update post content
    wp_update_post(array(
        'ID' => $post_id,
        'post_content' => 'Voice call transcribed and summarized in browser'
    ));

    error_log('[WebAgency] Results saved for post ' . $post_id);

    wp_send_json_success(array(
        'message' => 'Results saved successfully!',
        'post_id' => $post_id
    ));
}

add_action('wp_ajax_save_voice_results', 'webagency_save_voice_results');
add_action('wp_ajax_nopriv_save_voice_results', 'webagency_save_voice_results');

// Note: Legacy transcribe/summarize functions removed - processing is now done client-side


// Customize contact submission columns
function webagency_contact_columns($columns)
{
    return array(
        'cb' => $columns['cb'],
        'title' => 'Name',
        'email' => 'Email',
        'recording' => 'Voice Recording',
        'summary' => 'AI Summary',
        'transcription' => 'Transcription',
        'message_text' => 'Message', // Added message column
        'date' => 'Date'
    );
}
add_filter('manage_contact_submission_posts_columns', 'webagency_contact_columns');

function webagency_contact_column_content($column, $post_id)
{
    switch ($column) {
        case 'email':
            echo esc_html(get_post_meta($post_id, '_contact_email', true));
            break;
        case 'phone':
            echo esc_html(get_post_meta($post_id, '_contact_phone', true));
            break;
        case 'recording':
            echo get_post_meta($post_id, '_has_voice_recording', true) ? '✓ Yes' : '✗ No';
            break;
        case 'summary':
            $summary_status = get_post_meta($post_id, '_summary_status', true);
            $summary = get_post_meta($post_id, '_voice_summary', true);
            $transcription_status = get_post_meta($post_id, '_transcription_status', true);

            // Show summary if available
            if ($summary_status === 'completed' && $summary) {
                echo '<div style="max-height: 100px; overflow-y: auto;">' . $summary . '</div>';
            }
            // Fallback to transcription if summary not available but transcription is
            elseif ($transcription_status === 'completed' && !$summary) {
                $transcription = get_post_meta($post_id, '_voice_transcription', true);
                if ($transcription) {
                    echo '<span style="color: #999;" title="Summary not yet generated">📝 ' . $transcription . '</span>';
                } else {
                    echo '-';
                }
            }
            // Status indicators
            elseif ($summary_status === 'failed') {
                echo '<span style="color: #dc3232;">Summary Failed</span>';
            } elseif ($summary_status === 'pending') {
                echo '<span style="color: #f0b849;">Generating...</span>';
            } elseif ($transcription_status === 'failed') {
                echo '<span style="color: #dc3232;">Transcription Failed</span>';
            } elseif ($transcription_status === 'pending') {
                echo '<span style="color: #f0b849;">Transcribing...</span>';
            } else {
                echo '-';
            }
            break;

        case 'transcription':
            $transcription_status = get_post_meta($post_id, '_transcription_status', true);
            $transcription = get_post_meta($post_id, '_voice_transcription', true);

            if ($transcription_status === 'completed' && $transcription) {
                echo '<div style="max-height: 100px; overflow-y: auto;">' . $transcription . '</div>';
            } elseif ($transcription_status === 'pending') {
                echo '<span style="color: #f0b849;">Transcribing...</span>';
            } elseif ($transcription_status === 'failed') {
                echo '<span style="color: #dc3232;">Failed</span>';
            } else {
                echo '-';
            }
            break;

        case 'message_text':
            $message = get_post_meta($post_id, '_contact_message', true);
            if ($message) {
                echo '<div style="max-height: 100px; overflow-y: auto;">' . nl2br($message) . '</div>';
            } else {
                echo '-';
            }
            break;
    }
}
add_action('manage_contact_submission_posts_custom_column', 'webagency_contact_column_content', 10, 2);

// Register bulk actions for transcriptions and summaries
function webagency_register_bulk_actions($bulk_actions)
{
    $bulk_actions['regenerate_transcription'] = 'Regenerate Transcription';
    $bulk_actions['generate_summary'] = 'Generate AI Summary';
    return $bulk_actions;
}
add_filter('bulk_actions-edit-contact_submission', 'webagency_register_bulk_actions');

// Handle bulk action for regenerating transcriptions
function webagency_handle_bulk_regenerate_transcription($redirect_to, $doaction, $post_ids)
{
    if ($doaction !== 'regenerate_transcription') {
        return $redirect_to;
    }

    $processed = 0;
    $success = 0;
    $failed = 0;
    $skipped = 0;

    foreach ($post_ids as $post_id) {
        // Check if this submission has a voice recording
        $has_recording = get_post_meta($post_id, '_has_voice_recording', true);

        if (!$has_recording) {
            $skipped++;
            continue;
        }

        $recording_id = get_post_meta($post_id, '_voice_recording_id', true);
        if (!$recording_id) {
            $skipped++;
            continue;
        }

        $audio_file_path = get_attached_file($recording_id);

        if (!$audio_file_path || !file_exists($audio_file_path)) {
            $skipped++;
            continue;
        }

        // Note: Regeneration not supported - transcription is done client-side
        $skipped++;

        $processed++;
    }

    $redirect_to = add_query_arg(array(
        'bulk_regenerate_transcription' => '1',
        'processed' => $processed,
        'success' => $success,
        'failed' => $failed,
        'skipped' => $skipped
    ), $redirect_to);

    return $redirect_to;
}
add_filter('handle_bulk_actions-edit-contact_submission', 'webagency_handle_bulk_regenerate_transcription', 10, 3);

// Display admin notice for bulk transcription results
function webagency_bulk_transcription_admin_notice()
{
    if (!isset($_GET['bulk_regenerate_transcription'])) {
        return;
    }

    $processed = isset($_GET['processed']) ? intval($_GET['processed']) : 0;
    $success = isset($_GET['success']) ? intval($_GET['success']) : 0;
    $failed = isset($_GET['failed']) ? intval($_GET['failed']) : 0;
    $skipped = isset($_GET['skipped']) ? intval($_GET['skipped']) : 0;

    $message_parts = array();

    if ($success > 0) {
        $message_parts[] = sprintf('<strong>%d</strong> transcription(s) regenerated successfully', $success);
    }

    if ($failed > 0) {
        $message_parts[] = sprintf('<strong>%d</strong> transcription(s) failed', $failed);
    }

    if ($skipped > 0) {
        $message_parts[] = sprintf('<strong>%d</strong> submission(s) skipped (no voice recording)', $skipped);
    }

    if (!empty($message_parts)) {
        $message = implode(', ', $message_parts) . '.';
        $class = ($failed > 0) ? 'notice-warning' : 'notice-success';

        printf('<div class="notice %s is-dismissible"><p>%s</p></div>', esc_attr($class), $message);
    }
}
add_action('admin_notices', 'webagency_bulk_transcription_admin_notice');

// Handle bulk action for generating summaries
function webagency_handle_bulk_generate_summary($redirect_to, $doaction, $post_ids)
{
    if ($doaction !== 'generate_summary') {
        return $redirect_to;
    }

    $processed = 0;
    $success = 0;
    $failed = 0;
    $skipped = 0;

    foreach ($post_ids as $post_id) {
        // Check if this submission has a transcription
        $transcription = get_post_meta($post_id, '_voice_transcription', true);
        $transcription_status = get_post_meta($post_id, '_transcription_status', true);

        if (empty($transcription) || $transcription_status !== 'completed') {
            $skipped++;
            continue;
        }

        // Note: Summary generation not supported - summarization is done client-side
        $skipped++;

        $processed++;
    }

    $redirect_to = add_query_arg(array(
        'bulk_generate_summary' => '1',
        'processed' => $processed,
        'success' => $success,
        'failed' => $failed,
        'skipped' => $skipped
    ), $redirect_to);

    return $redirect_to;
}
add_filter('handle_bulk_actions-edit-contact_submission', 'webagency_handle_bulk_generate_summary', 10, 3);

// Display admin notice for bulk summary generation results
function webagency_bulk_summary_admin_notice()
{
    if (!isset($_GET['bulk_generate_summary'])) {
        return;
    }

    $processed = isset($_GET['processed']) ? intval($_GET['processed']) : 0;
    $success = isset($_GET['success']) ? intval($_GET['success']) : 0;
    $failed = isset($_GET['failed']) ? intval($_GET['failed']) : 0;
    $skipped = isset($_GET['skipped']) ? intval($_GET['skipped']) : 0;

    $message_parts = array();

    if ($success > 0) {
        $message_parts[] = sprintf('<strong>%d</strong> summary/summaries generated successfully', $success);
    }

    if ($failed > 0) {
        $message_parts[] = sprintf('<strong>%d</strong> summary/summaries failed', $failed);
    }

    if ($skipped > 0) {
        $message_parts[] = sprintf('<strong>%d</strong> submission(s) skipped (no transcription)', $skipped);
    }

    if (!empty($message_parts)) {
        $message = implode(', ', $message_parts) . '.';
        $class = ($failed > 0) ? 'notice-warning' : 'notice-success';

        printf('<div class="notice %s is-dismissible"><p>%s</p></div>', esc_attr($class), $message);
    }
}
add_action('admin_notices', 'webagency_bulk_summary_admin_notice');

// Add settings page for LLM configuration
function webagency_add_settings_page()
{
    add_options_page(
        'WebAgency AI Settings',
        'AI Settings',
        'manage_options',
        'webagency-ai-settings',
        'webagency_render_settings_page'
    );
}
add_action('admin_menu', 'webagency_add_settings_page');

function webagency_render_settings_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    // Save settings
    if (isset($_POST['webagency_save_settings'])) {
        check_admin_referer('webagency_settings_nonce');

        update_option('webagency_model_path', sanitize_text_field($_POST['model_path']));

        echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
    }

    $theme_dir = get_template_directory();
    $default_model = $theme_dir . '/scripts/models/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf';
    $model_path = get_option('webagency_model_path', $default_model);

    ?>
    <div class="wrap">
        <h1>WebAgency AI Settings</h1>
        <form method="post" action="">
            <?php wp_nonce_field('webagency_settings_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="model_path">Model File Path</label>
                    </th>
                    <td>
                        <input type="text" id="model_path" name="model_path" value="<?php echo esc_attr($model_path); ?>"
                            class="large-text" />
                        <p class="description">Path to GGUF model file (e.g., tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf)</p>
                        <p class="description">Default: <?php echo esc_html($default_model); ?></p>
                        <p class="description">Download models from: <a href="https://huggingface.co/TheBloke"
                                target="_blank">TheBloke on HuggingFace</a></p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="webagency_save_settings" class="button button-primary" value="Save Settings" />
            </p>
        </form>

        <hr />

        <h2>Test Model</h2>
        <p>Use this to verify your model is accessible and working.</p>
        <button type="button" id="test-model" class="button">Test Model</button>
        <div id="model-test-result" style="margin-top: 10px;"></div>

        <script>
            jQuery(document).ready(function ($) {
                $('#test-model').on('click', function () {
                    var button = $(this);
                    var resultDiv = $('#model-test-result');

                    button.prop('disabled', true).text('Testing...');
                    resultDiv.html('<p>Testing model... This may take a few seconds on first run.</p>');

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'test_llm_model',
                            nonce: '<?php echo wp_create_nonce('test_llm_model'); ?>'
                        },
                        timeout: 60000,
                        success: function (response) {
                            if (response.success) {
                                resultDiv.html('<div class="notice notice-success inline"><p>' + response.data.message + '</p></div>');
                            } else {
                                resultDiv.html('<div class="notice notice-error inline"><p>' + response.data.message + '</p></div>');
                            }
                        },
                        error: function () {
                            resultDiv.html('<div class="notice notice-error inline"><p>Request timed out or failed. Check error logs.</p></div>');
                        },
                        complete: function () {
                            button.prop('disabled', false).text('Test Model');
                        }
                    });
                });
            });
        </script>
    </div>
    <?php
}

// Add custom admin CSS for contact submission list
function webagency_admin_custom_css()
{
    $screen = get_current_screen();
    if ($screen->id === 'edit-contact_submission') {
        echo '<style>
            .column-summary, .column-transcription, .column-message_text {
                width: 250px !important;
                white-space: normal !important;
                word-wrap: break-word !important;
            }
            .column-summary div, .column-transcription div, .column-message_text div {
                font-size: 11px;
                line-height: 1.3;
                color: #444;
            }
        </style>';
    }
}
add_action('admin_head', 'webagency_admin_custom_css');


