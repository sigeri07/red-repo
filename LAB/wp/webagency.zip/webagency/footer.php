<footer class="bg-gray-900 text-white py-12">
    <div class="container mx-auto px-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
                <h3 class="text-2xl font-bold mb-4">WebAgency</h3>
                <p class="text-gray-400">Creating exceptional digital experiences for businesses worldwide.</p>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                <ul class="space-y-2">
                    <li><a href="#home" class="text-gray-400 hover:text-white transition">Home</a></li>
                    <li><a href="#cases" class="text-gray-400 hover:text-white transition">Cases</a></li>
                    <li><a href="#team" class="text-gray-400 hover:text-white transition">Team</a></li>
                    <li><a href="#contact" class="text-gray-400 hover:text-white transition">Contact</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Contact Info</h4>
                <ul class="space-y-2 text-gray-400">
                    <li>Email: info@webagency.com</li>
                    <li>Phone: +1 (555) 123-4567</li>
                    <li>Address: 123 Digital St, Tech City</li>
                </ul>
            </div>
        </div>
        <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; <?php echo date('Y'); ?> WebAgency. All rights reserved.</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
