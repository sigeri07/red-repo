<?php get_header(); ?>

<!-- Hero Section -->
<section id="home" class="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white pt-20">
    <div class="container mx-auto px-6 text-center">
        <h1 class="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
            We Build Digital Experiences
        </h1>
        <p class="text-xl md:text-2xl mb-8 text-blue-100">
            Transform your business with cutting-edge web solutions
        </p>
        <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#contact" class="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition transform hover:scale-105">
                Get Started
            </a>
            <a href="#cases" class="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition transform hover:scale-105">
                View Our Work
            </a>
        </div>
    </div>
</section>

<!-- Cases Section -->
<section id="cases" class="py-20 bg-gray-50">
    <div class="container mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Our Cases</h2>
            <p class="text-xl text-gray-600">Successful projects we're proud of</p>
        </div>

        <div class="swiper casesSwiper">
            <div class="swiper-wrapper">
                <?php
                $cases = new WP_Query(array(
                    'post_type' => 'case',
                    'posts_per_page' => -1
                ));

                if ($cases->have_posts()) :
                    while ($cases->have_posts()) : $cases->the_post();
                ?>
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="h-64 overflow-hidden">
                                    <?php the_post_thumbnail('large', array('class' => 'w-full h-full object-cover')); ?>
                                </div>
                            <?php endif; ?>
                            <div class="p-6">
                                <h3 class="text-2xl font-bold text-gray-900 mb-3"><?php the_title(); ?></h3>
                                <div class="text-gray-600">
                                    <?php the_excerpt(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else:
                ?>
                    <!-- Default cases if none exist -->
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                            <div class="h-64 overflow-hidden">
                                <img src="https://images.unsplash.com/photo-1557821552-17105176677c?w=800&h=600&fit=crop" alt="E-Commerce Platform" class="w-full h-full object-cover">
                            </div>
                            <div class="p-6">
                                <h3 class="text-2xl font-bold text-gray-900 mb-3">E-Commerce Platform</h3>
                                <p class="text-gray-600">Built a scalable e-commerce solution handling 100K+ daily transactions with seamless user experience.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                            <div class="h-64 overflow-hidden">
                                <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop" alt="SaaS Dashboard" class="w-full h-full object-cover">
                            </div>
                            <div class="p-6">
                                <h3 class="text-2xl font-bold text-gray-900 mb-3">SaaS Dashboard</h3>
                                <p class="text-gray-600">Developed an intuitive analytics dashboard for a B2B SaaS company, improving user engagement by 200%.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                            <div class="h-64 overflow-hidden">
                                <img src="https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&h=600&fit=crop" alt="Mobile Banking App" class="w-full h-full object-cover">
                            </div>
                            <div class="p-6">
                                <h3 class="text-2xl font-bold text-gray-900 mb-3">Mobile Banking App</h3>
                                <p class="text-gray-600">Created a secure and user-friendly mobile banking application with biometric authentication.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                            <div class="h-64 overflow-hidden">
                                <img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop" alt="Healthcare Portal" class="w-full h-full object-cover">
                            </div>
                            <div class="p-6">
                                <h3 class="text-2xl font-bold text-gray-900 mb-3">Healthcare Portal</h3>
                                <p class="text-gray-600">Designed a HIPAA-compliant patient portal connecting healthcare providers and patients seamlessly.</p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="swiper-pagination mt-8"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section id="team" class="py-20 bg-white">
    <div class="container mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Our Team</h2>
            <p class="text-xl text-gray-600">Meet the talented people behind our success</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php
            $team = new WP_Query(array(
                'post_type' => 'team_member',
                'posts_per_page' => -1
            ));

            if ($team->have_posts()) :
                while ($team->have_posts()) : $team->the_post();
                    $position = get_post_meta(get_the_ID(), '_team_position', true);
            ?>
                <div class="text-center group">
                    <div class="relative mb-4 overflow-hidden rounded-lg">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('medium', array('class' => 'w-full h-80 object-cover transform group-hover:scale-110 transition duration-300')); ?>
                        <?php else: ?>
                            <div class="w-full h-80 bg-gradient-to-br from-blue-400 to-purple-400"></div>
                        <?php endif; ?>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-1"><?php the_title(); ?></h3>
                    <p class="text-blue-600 font-semibold"><?php echo esc_html($position); ?></p>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else:
            ?>
                <!-- Default team members if none exist -->
                <div class="text-center group">
                    <div class="relative mb-4 overflow-hidden rounded-lg">
                        <img src="https://i.pravatar.cc/400?img=12" alt="John Smith" class="w-full h-80 object-cover transform group-hover:scale-110 transition duration-300">
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-1">John Smith</h3>
                    <p class="text-blue-600 font-semibold">CEO & Founder</p>
                </div>
                <div class="text-center group">
                    <div class="relative mb-4 overflow-hidden rounded-lg">
                        <img src="https://i.pravatar.cc/400?img=45" alt="Sarah Johnson" class="w-full h-80 object-cover transform group-hover:scale-110 transition duration-300">
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-1">Sarah Johnson</h3>
                    <p class="text-blue-600 font-semibold">Lead Designer</p>
                </div>
                <div class="text-center group">
                    <div class="relative mb-4 overflow-hidden rounded-lg">
                        <img src="https://i.pravatar.cc/400?img=33" alt="Michael Chen" class="w-full h-80 object-cover transform group-hover:scale-110 transition duration-300">
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-1">Michael Chen</h3>
                    <p class="text-blue-600 font-semibold">Tech Lead</p>
                </div>
                <div class="text-center group">
                    <div class="relative mb-4 overflow-hidden rounded-lg">
                        <img src="https://i.pravatar.cc/400?img=47" alt="Emily Davis" class="w-full h-80 object-cover transform group-hover:scale-110 transition duration-300">
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-1">Emily Davis</h3>
                    <p class="text-blue-600 font-semibold">Marketing Director</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section id="contact" class="py-20 bg-gray-50">
    <div class="container mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Get In Touch</h2>
            <p class="text-xl text-gray-600">Let's discuss your next project</p>
        </div>

        <div class="max-w-2xl mx-auto">
            <form id="contactForm" class="bg-white rounded-lg shadow-lg p-8">
                <div class="mb-6">
                    <label for="name" class="block text-gray-700 font-semibold mb-2">Name</label>
                    <input type="text" id="name" name="name" required
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                </div>

                <div class="mb-6">
                    <label for="email" class="block text-gray-700 font-semibold mb-2">Email</label>
                    <input type="email" id="email" name="email" required
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                </div>

                <div class="mb-6">
                    <label for="phone" class="block text-gray-700 font-semibold mb-2">Phone</label>
                    <input type="tel" id="phone" name="phone"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                </div>

                <div class="mb-6">
                    <label for="message" class="block text-gray-700 font-semibold mb-2">Message</label>
                    <textarea id="message" name="message" rows="5" required
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"></textarea>
                </div>

                <button type="submit"
                        class="w-full bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition">
                    Send Message
                </button>

                <div id="formMessage" class="mt-6 hidden"></div>
            </form>
        </div>
    </div>
</section>

<!-- Floating Call Button -->
<button id="floatingCallBtn" class="floating-call-btn">
    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
    </svg>
</button>

<!-- Call Modal -->
<div id="callModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4">
        <div class="text-center">
            <div class="mb-6">
                <div class="w-20 h-20 bg-green-100 rounded-full mx-auto flex items-center justify-center mb-4">
                    <svg class="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                    </svg>
                </div>
                <h3 class="text-2xl font-bold text-gray-900 mb-2">Call WebAgency</h3>
                <p id="callStatus" class="text-gray-600 mb-4">Ready to connect</p>
            </div>

            <div id="recordingControls" class="hidden">
                <div class="mb-4">
                    <div class="flex items-center justify-center gap-2 text-red-600">
                        <span class="w-3 h-3 bg-red-600 rounded-full animate-pulse"></span>
                        <span class="font-semibold">Recording...</span>
                    </div>
                    <p class="text-sm text-gray-500 mt-2">Speak your message after the beep</p>
                </div>
            </div>

            <div id="modalButtons">
                <button id="startCallBtn" class="bg-green-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-green-700 transition mb-3 w-full">
                    Call
                </button>
                <button id="closeModalBtn" class="text-gray-600 hover:text-gray-800 font-semibold">
                    Cancel
                </button>
            </div>

            <button id="hangupBtn" class="hidden bg-red-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-red-700 transition">
                Hang Up
            </button>
        </div>
    </div>
</div>

<?php get_footer(); ?>
