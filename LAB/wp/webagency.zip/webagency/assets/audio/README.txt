Audio Files Directory
====================

This directory should contain audio files for the call modal feature.

Required file:
- waiting-message.mp3: The message played when users click "Call Us"

Sample message: "All operators are currently busy. Please leave your message after the beep."

Note: If the audio file is not present, the system will automatically use browser's
text-to-speech synthesis as a fallback.

You can generate an MP3 file using:
1. Text-to-speech services (Google TTS, Amazon Polly, etc.)
2. Recording your own voice
3. Any audio editing software

The JavaScript code will handle the fallback automatically.
