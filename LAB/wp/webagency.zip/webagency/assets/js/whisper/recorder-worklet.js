/**
 * Audio Recorder Worklet
 * High-performance audio capture in the audio thread
 * Captures raw PCM data at 16kHz and sends to main thread
 */

class RecorderWorklet extends AudioWorkletProcessor {
    constructor() {
        super();
        this.isRecording = true;
    }

    process(inputs, outputs, parameters) {
        const input = inputs[0];

        if (input && input.length > 0 && this.isRecording) {
            // Get mono channel (channel 0)
            const channelData = input[0];

            // Create a copy to send to main thread
            // (transferring ownership would be more efficient but requires SharedArrayBuffer)
            const audioCopy = new Float32Array(channelData);

            // Send PCM data to main thread
            this.port.postMessage({
                type: 'audioData',
                data: audioCopy
            });
        }

        // Keep processor alive
        return this.isRecording;
    }
}

// Register the processor
registerProcessor('recorder-worklet', RecorderWorklet);