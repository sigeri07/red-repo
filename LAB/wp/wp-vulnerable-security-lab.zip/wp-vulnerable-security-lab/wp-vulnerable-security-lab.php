<?php
/*
Plugin Name: WordPress Vulnerable Security Lab
Description: Intentionally vulnerable WordPress plugin for security training. Includes XSS, SQLi and Upload labs accessible from frontend.
Version: 1.0
Author: Security Training Lab
License: GPL2
*/

if (!defined('ABSPATH')) exit;


/* ============================
REGISTER FRONTEND ROUTES
============================ */

add_action('init', function(){

    add_rewrite_rule('^xss-lab/?','index.php?vuln_lab=xss','top');
    add_rewrite_rule('^sqli-lab/?','index.php?vuln_lab=sqli','top');
    add_rewrite_rule('^upload-lab/?','index.php?vuln_lab=upload','top');

});


add_filter('query_vars', function($vars){

    $vars[] = 'vuln_lab';
    return $vars;

});


add_action('template_redirect','vuln_lab_router');


/* ============================
ROUTER
============================ */

function vuln_lab_router(){

$lab = get_query_var('vuln_lab');

if(!$lab) return;

switch($lab){

case "xss":
vuln_xss();
break;

case "sqli":
vuln_sqli();
break;

case "upload":
vuln_upload();
break;

}

exit;

}


/* ============================
LAYOUT
============================ */

function vuln_header($title){

echo "<html>";
echo "<head>";
echo "<title>$title</title>";

echo "<style>

body{
font-family:Arial;
background:#f4f6f8;
margin:0;
padding:40px;
}

.box{
max-width:900px;
margin:auto;
background:white;
padding:30px;
border-radius:8px;
box-shadow:0 2px 10px rgba(0,0,0,0.1);
}

.lab{
background:#fff3cd;
padding:10px;
border-left:5px solid orange;
margin-bottom:20px;
}

</style>";

echo "</head>";
echo "<body>";
echo "<div class='box'>";
echo "<h1>$title</h1>";

}


function vuln_footer(){

echo "</div>";
echo "</body>";
echo "</html>";

}


/* ============================
XSS LAB
============================ */

function vuln_xss(){

$current_user = wp_get_current_user();

vuln_header("Reflected XSS Lab");

echo "<div class='lab'>This page is vulnerable to reflected XSS.</div>";

if(isset($_GET['msg'])){

$msg = $_GET['msg'];

echo "Output: ".$msg." ".$current_user->user_login;

}else{

echo "<p>Try payload:</p>";

echo "<pre>?msg=&lt;script&gt;alert(document.cookie)&lt;/script&gt;</pre>";

}

vuln_footer();

}


/* ============================
SQLI LAB
============================ */

function vuln_sqli(){

global $wpdb;

$table = $wpdb->users;

vuln_header("SQL Injection Lab");

?>

<form>

User ID:

<input name="id">

<button>Search</button>

</form>

<?php

if(isset($_GET['id'])){

$id = $_GET['id'];

$query = "SELECT ID,user_login,user_email FROM $table WHERE ID = $id";

echo "<h3>Query</h3>";
echo "<pre>$query</pre>";

$results = $wpdb->get_results($query);

echo "<h3>Results</h3>";

if($results){

foreach($results as $r){

echo "ID: ".$r->ID."<br>";
echo "User: ".$r->user_login."<br>";
echo "Email: ".$r->user_email."<br><br>";

}

}else{

echo "No results";

}

echo "<h3>Payload Example</h3>";

echo "<pre>1 OR 1=1</pre>";

}

vuln_footer();

}


/* ============================
UPLOAD LAB
============================ */

function vuln_upload(){

vuln_header("File Upload Lab");

?>

<form method="POST" enctype="multipart/form-data">

Upload file:

<input type="file" name="file">

<input type="submit">

</form>

<?php

if(isset($_FILES['file'])){

$upload = wp_upload_dir();

$target = $upload['basedir']."/".$_FILES['file']['name'];

move_uploaded_file($_FILES['file']['tmp_name'],$target);

echo "Uploaded to: ".$target;

}

echo "<p>Try uploading PHP shell.</p>";

vuln_footer();

}